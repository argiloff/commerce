export const TAGS = {
  cart: 'cart',
  wishlist: 'wishlist',
};

export const DEFAULT_OPTION = 'default'; // Hinzugefügt
